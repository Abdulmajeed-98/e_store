import 'package:flutter/material.dart';
import 'package:untitled37/models/product.dart';
import 'package:untitled37/views/cart_screen.dart';
import 'package:untitled37/views/details_screen.dart';
import 'package:untitled37/views/home_screen.dart';
import 'package:untitled37/views/login_screen.dart';
import 'package:untitled37/views/not_found.dart';
import 'package:untitled37/views/splash_screen.dart';

class AppRoutes{
  static Route<dynamic>? routeManager(RouteSettings settings ){

    switch(settings.name){
      case '/home': return MaterialPageRoute(builder: (ctx)=>HomeScreen());
      case '/details':{ return MaterialPageRoute(builder: (ctx)=>DetailsScreen(),settings: settings);}
      case '/cart':{
        List<Map<Product,int>> cartItems=settings.arguments as List<Map<Product,int>>;
        return MaterialPageRoute(builder: (ctx)=>CartScreen(cart: cartItems));}
      case '/splash': return MaterialPageRoute(builder: (ctx)=>SplashScreen());
      case '/login': return MaterialPageRoute(builder: (ctx)=>LoginScreen());
      default:return MaterialPageRoute(builder: (ctx)=>NotFoundScreen());
    }


  }
}